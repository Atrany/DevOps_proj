import time
from random import *
from datetime import datetime
import json



num_auto = 1
type_auto = 0X0000BA20
temp_cuve = 0
temp_ext = 0
poid_lait = 0
poid_prod_fini = 0
mesur_ph = 0
mesur_k = 0
concen_nacl = 0
niv_b_salmonel = 0
niv_b_ecoli = 0
niv_b_list = 0
now = datetime.now()
timestamp = datetime.timestamp(now)
date = timestamp /1000

while num_auto <= 10:
    temp_cuve = uniform(2.5, 4)
    temp_ext = uniform(8, 14)
    poid_lait = uniform(3512, 4607)
    poid_prod_fini = poid_lait
    mesur_ph = uniform(6.8, 7.2)
    mesur_k = uniform(35, 47)
    concen_nacl = uniform(1, 1.7)
    niv_b_salmonel = uniform(17, 37)
    niv_b_ecoli = uniform(35, 49)
    niv_b_list = uniform(28, 54)
    num_auto = num_auto + 1
    time.sleep(60)

data = {}
data['automate'] = []
data['automate'].append({
    'Numéro d’automate': num_auto,
    'Type d’automate': type_auto,
    'Température cuve': temp_cuve,
    'Température extérieure': temp_ext,
    'Poids du lait en cuve': poid_lait,
    'Poids du produit fini réalisé': poid_prod_fini,
    'Mesure pH': mesur_ph,
    'Mesure K+': mesur_k,
    'Concentration de NaCl': concen_nacl,
    'Niveau bactérien salmonelle': niv_b_salmonel,
    'Niveau bactérien E-coli': niv_b_ecoli,
    'Niveau bactérien Listéria': niv_b_list,
    'date unix epoch': date + "%s"
})
with open('automate.json', 'w') as outfile:
    json.dump(data, outfile)